---
name: sdlc-doctor
description: Use when onboarding a repo, diagnosing hook or session errors, or installing SDLC skills across AI agents. Not for feature coding. Runs detect, doctor, and install.
allowed-tools: Read, Write, Edit, Bash
---

# Environment Doctor, Stack Discovery & Multi-Agent Installer (`sdlc-doctor`)

## When to use / When NOT to use
- **Use when** setting up a new repository, diagnosing outdated 4-Layer Git hooks or stale sessions, refreshing `.agent/sdlc-config.json`, or provisioning skills for Gemini, Claude Code/Cowork, Cursor, Grok, Windsurf, and Copilot.
- **Not for** implementing product features or running PR reviews (`sdlc-flow`, `sdlc-gate`).

## Lane behavior
| Operation | Side-effect level | Command |
| :--- | :--- | :--- |
| **Diagnose (default)** | Read-only (`0` writes) | `node .agent/scripts/sdlc-engine.mjs doctor` + `skill-audit` |
| **Auto-Heal** | Workspace writes | `node .agent/scripts/sdlc-engine.mjs doctor --fix` (heals `KANBAN.md`, `.archlens/policy.json`, SHA-256 verified `.git/hooks/*`, and `.github/workflows/sdlc-quality-gate.yml`) |
| **Agent Install** | Local or `~/` writes (`sdlc*` only) | `install` or `interop export` across selected AI coding agents (provisions the 10 `sdlc*` skills and prunes retired `sdlc-*` skills while leaving standalone user/third-party skills untouched) |

## Steps

```bash
# 1. Read-only healthcheck (toolchain, assets, session locks, SHA-256 hook drift, skill audit)
node .agent/scripts/sdlc-engine.mjs doctor
node .agent/scripts/sdlc-engine.mjs skill-audit

# 2. Detect polyglot stack (Node/TS, Python, Java, Go, Rust) & write .agent/sdlc-config.json
node .agent/scripts/sdlc-engine.mjs detect

# 3. Auto-heal missing or outdated hooks/policy/CI workflow (after user confirmation)
node .agent/scripts/sdlc-engine.mjs doctor --fix

# 4. Targeted single-asset repair (only when doctor reports just one item out of date)
node .agent/scripts/sdlc-engine.mjs hooks install
node .agent/scripts/sdlc-engine.mjs archlens scaffold

# 5. Provision canonical skills & non-destructive rules across AI agents
node .agent/scripts/sdlc-engine.mjs interop export --agent gemini,claude,cursor
node .agent/scripts/sdlc-engine.mjs install --agents gemini,claude,cursor --with-archlens --with-hooks --yes
```

## ⚠️ Confirm with user before
- Running `doctor --fix` when the user only asked to diagnose or inspect repo health.
- Running `interop export --agent all` (creates rule/skill directories for agents the repo may not use) or `install --global` (writes into `~/.gemini`, `~/.claude`, `~/.cursor`, `~/.grok`).

## If it fails
- **`hooks install` fails inside a sandbox** (`.git/hooks` write blocked) -> re-run `hooks install` outside any restricted sandbox.
- **`skill-audit` reports `FM1`/`FM2`/`RP1`/`AS3` findings** -> quote YAML `description`, pin `npx pkg@1.2.0`, and remove cross-skill file path references.

## Done when
`doctor` reports healthy toolchain, up-to-date SHA-256 Git hooks, valid `.agent/sdlc-config.json`, and `0` `skill-audit` findings.
