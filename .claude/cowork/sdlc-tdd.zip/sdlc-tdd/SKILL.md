---
name: sdlc-tdd
description: Guides Robert C. Martin Test-Driven Development (Red-Green-Refactor, Transformation Priority Premise, F.I.R.S.T. isolation) and executes real Dual-Gate test coverage (>= 85%) and mutation testing (>= 80%) across polyglot stacks.
allowed-tools: Read, Write, Edit, Bash
---

# 🧪 Robert Martin TDD & Dual-Gate Verification (`sdlc-tdd`)

## 1. The Three Laws of TDD & Transformation Priority Premise (TPP)

1. **First Law (Red)**: Write a failing unit test before writing production code.
2. **Second Law (Red Constraint)**: Write no more of a unit test than is sufficient to fail.
3. **Third Law (Green)**: Write no more production code than is sufficient to pass the failing test, evolving logic from specific to generic (`nil -> constant -> scalar -> conditional -> iteration`).
4. **Refactor**: Eliminate duplication, enforce Single Responsibility Principle (SRP), and apply Dependency Inversion (ports & adapters) before starting the next cycle.

---

## 2. Zero-Tolerance Test Anti-Patterns

- **No Assertion-Free Tests ("Smoke Screen")**: Every test must assert a specific behavioral outcome (`assert.equal`, `assert.deepEqual`, `assertEquals`), never just calling a method to inflate line coverage.
- **No Trivial Accessor Tests**: Do not write tests solely for plain getters/setters or framework boilerplate.
- **No Mock Abuse**: Prefer lightweight in-memory fakes or real domain objects over deeply nested mocks that test mock wiring instead of business rules.
- **F.I.R.S.T. Isolation**: Tests must be Fast, Independent, Repeatable (ephemeral ports/temp dirs), Self-Validating, and Timely.
- **ub-mode Alignment**: Adhere to Robert C. Martin's reduced principles (`ub-mode`): First Make it Work (Laziness Protocol, Subtract Before You Add, Attack the Premise), Then Make it Right (CRAP < 10, DRY < 0.8, Mutation kill >= 80%), and Follow Practice.

---

## 3. Polyglot Dual-Gate Execution Commands

### Step 1: Fast Affected-Only Test Loop
During Red-Green-Refactor cycles, run only the tests affected by your git diff:
```bash
node .agent/scripts/sdlc-engine.mjs test --affected-only
```

### Step 2: Gate 1 — Real Coverage Verification ($\ge 85\%$)
Execute the stack-aware coverage runner and parser (`coverage-summary.json`, `lcov.info`, `jacoco.csv`, `coverage.xml`, `coverage.out`):
```bash
node .agent/scripts/sdlc-engine.mjs coverage --no-cache
```
The engine parses the generated coverage artifact on disk, verifies it meets `thresholds.diffCoverage` ($85\%$), and records the measured percentage in `.agent/.sdlc-session.json`.

### Step 3: Gate 2 — Mutation Testing & Strengthening ($\ge 80\%$)
Execute mutation testing (Stryker, PITest, `mutmut`, `cargo-mutants`) and parse the resulting mutation report:
```bash
node .agent/scripts/sdlc-engine.mjs mutation
```
If a mutant survives, generate targeted assertion advice:
```bash
node .agent/scripts/sdlc-engine.mjs strengthen --type <ConditionalsBoundary|NegateCondition|Math|VoidMethodCall|EmptyReturn> --file <path>
```
If a surviving mutant is a verified compiler/logging artifact, record an audited exemption:
```bash
node .agent/scripts/sdlc-engine.mjs exemption add --mutant "<id>" --file "<path>" --reason "<justification>"
```

### Step 4: Flake Resistance Check
Verify zero non-deterministic timing or shared-state flakes across repeated runs:
```bash
node .agent/scripts/sdlc-engine.mjs flake-check --runs 5
```
